package com.baeldung.springpagination.service;

import com.baeldung.springpagination.model.User;

public interface IUserService {

    User getCurrentUser();

}
