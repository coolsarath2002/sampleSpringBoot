package com.baeldung;

public interface Consts {
    int APPLICATION_PORT = 8080;
}
